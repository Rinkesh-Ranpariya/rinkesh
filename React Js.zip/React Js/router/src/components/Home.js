import React from "react";

function Home() {
  return (
    <div className="home_image d-flex justify-content-center align-items-center">
      <h1 className="text-dark">We are Educator...📚📙</h1>
    </div>
  );
}

export default Home;
