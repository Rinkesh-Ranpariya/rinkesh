import React from "react";

function About({ isDark }) {
  return (
    <div className="pb-5">
      <h1 className="mt-5">About</h1>
      <div
        className={`jumbotron w-75 mx-auto mt-5 mb-0 ${
          isDark ? "dark border border-white" : "light border border-dark"
        }`}
      >
        <h1 className="display-5">We are Future !!!</h1>
        <p className="lead">
          We envision a world where anyone, anywhere has the power to transform
          their life through learning.
        </p>
        <hr className="my-4" />
        <p>
          Edukey partners with more than 200 leading universities and companies
          to bring flexible, affordable, job-relevant online learning to
          individuals and organizations worldwide. We offer a range of learning
          opportunities—from hands-on projects and courses to job-ready
          certificates and degree programs.
        </p>
        <h2>Our story</h2>
        <p>
          Edukey was founded by Daphne Koller and Andrew Ng in 2012 with a
          vision of providing life-transforming learning experiences to learners
          around the world. Today, Edukey is a global online learning platform
          that offers anyone, anywhere, access to online courses and degrees
          from leading universities and companies. Edukey received B Corp
          certification in February 2021, which means that we have a legal duty
          not only to our shareholders, but to also make a positive impact on
          society more broadly, as we continue our efforts to reduce barriers to
          world-class education for all. 82 million learners, 100+ Fortune 500
          companies, and more than 6,000 campuses, businesses, and governments
          come to Edukey to access world-class learning—anytime, anywhere.
        </p>
      </div>
    </div>
  );
}

export default About;
