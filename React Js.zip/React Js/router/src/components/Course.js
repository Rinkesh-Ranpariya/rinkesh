import React from "react";
import {
  useNavigate,
  useParams,
  useSearchParams,
  Link,
} from "react-router-dom";
import { getCourses } from "../data";

function Course({ isDark }) {
  const navigate = useNavigate();
  const { course } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const courses = getCourses();

  const handleBack = () => {
    navigate("/courses");
  };

  return (
    <div className="pb-5">
      <h1 className="mt-5">Course - {course}</h1>
      <h3>discount - {searchParams.get("discount")}</h3>
      <button
        type="submit"
        onClick={handleBack}
        className="btn btn-outline-info"
      >
        👈 Back to All Courses
      </button>

      <div className="container mt-5">
        <div className="container-fluid">
          <div className="row">
            {courses
              .filter((courseObj) => courseObj.name === course)
              .map((course) => (
                <div
                  className="card"
                  key={course.number}
                  style={{ width: "18rem", margin: "10px 20px" }}
                >
                  <img src={course.img} className="card-img-top" alt="..." />
                  <div className={`card-body ${isDark ? "dark" : "light"}`}>
                    <h3 className="card-title">{course.name}</h3>
                    <p className="card-text">
                      Some quick example text to build on the card title and
                      make up the bulk of the card's content.
                    </p>
                    <h4 className="card-text">{course.amount}</h4>
                    <Link to="/purchase" className="btn btn-primary">
                      Purchase
                    </Link>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Course;
