import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (
    <nav className="navbar navbar-dark bg-dark">
      <ul className="navbar-nav mx-auto">
        <li className="active">
          <Link to="/" className="nav-link">
            &copy; 2022 All Right Reserve
          </Link>
        </li>
      </ul>
    </nav>
  );
}

export default Footer;
