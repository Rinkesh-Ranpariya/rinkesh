import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "./Authentication";

function Logout() {
  let navigate = useNavigate();
  let location = useLocation();
  const auth = useAuth();

  let data = {
    msg: "Thank-you for visiting us !",
  };

  const handleLogout = () => {
    auth.logout();

    navigate("/logout", { state: data }, { replace: true });
  };

  return (
    <>
      <h1 className="mt-5">Logout</h1>
      {!location.state?.msg ? (
        <button onClick={handleLogout} className="mt-5 btn btn-outline-danger">
          Logout
        </button>
      ) : (
        <h4 className="mt-5">{location.state.msg}</h4>
      )}
    </>
  );
}

export default Logout;
