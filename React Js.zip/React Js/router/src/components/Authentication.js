import React, { useContext, useState } from "react";
const userContext = React.createContext();

const useAuth = () => {
  return useContext(userContext);
};

function Authentication({ children }) {
  const [user, setUser] = useState("");

  const login = (user) => {
    setUser(user);
  };

  const logout = () => {
    setUser("");
  };

  return (
    <userContext.Provider value={{ user, login, logout }}>
      {children}
    </userContext.Provider>
  );
}

export { Authentication, useAuth };
