// https://codesandbox.io/s/hooks-463jtk?file=/src/App.js

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Navbar from "./components/Navbar";
import Callback from "./components/useCallback/Callback";
import Home from "./components/Home";
import Memo from "./components/useMemo/Memo";
import Ref from "./components/useRef/Ref";
import Context from "./components/useContext/Context";
import Reducer from "./components/useReducer/Reducer";
import ComplexReducer from "./components/useReducer/ComplexReducer";
import HttpReducer from "./components/useReducer/HttpReducer";
import Effect from "./components/useEffect/Effect";
import State from "./components/useState/State";
import { useState } from "react";

function App() {
  const [isDark, setIsDark] = useState(false);

  const handlerMode = () => {
    setIsDark(!isDark)
  };

  return (
    <Router>
      <div className={`App ${isDark?"dark":"light"}`}>
        <Navbar isDark={isDark} func={handlerMode} />
        <div className="p-5">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/useState" element={<State isDark={isDark}/>} />
            <Route path="/useEffect" element={<Effect isDark={isDark}/>} />
            <Route path="/useContext" element={<Context />} />
            <Route path="/simpleUseReducer" element={<Reducer />} />
            <Route path="/complexUseReducer" element={<ComplexReducer />} />
            <Route path="/httpReducer" element={<HttpReducer isDark={isDark}/>} />
            <Route path="/useCallback" element={<Callback />} />
            <Route path="/useMemo" element={<Memo />} />
            <Route path="/useRef" element={<Ref />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;