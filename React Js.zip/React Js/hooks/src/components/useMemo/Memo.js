import React, { useMemo, useState } from "react";

function Memo() {
  const [counterOne, setCounterOne] = useState(0);
  const [counterTwo, setCounterTwo] = useState(0);

  const handlerIncrementCounterOne = () => {
    setCounterOne(counterOne + 1);
  };

  const handlerIncrementCounterTwo = () => {
    setCounterTwo(counterTwo + 1);
  };

  const isEven = useMemo(() => {
    let i=0;
    while(i<2000000000) i++;
    return counterOne % 2 === 0;
  },[counterOne]) 

  return (
    <>
      <h1>useMemo Hook🪝</h1>
      <hr />
      <div className="mt-5">
        <button
          onClick={handlerIncrementCounterOne}
          className="btn btn-success"
        >
          counterOne - {counterOne}
        </button>
        <span className="ml-4">{counterOne} is {isEven ? "Even" : "Odd"}</span>
      </div>

      <div>
        <button
          onClick={handlerIncrementCounterTwo}
          className="btn btn-success mt-5" 
        >
          counterTwo - {counterTwo}
        </button>
      </div>
    </>
  );
}

export default Memo;
