import React, { useEffect, useRef, useState } from "react";

function RefDate() {

  const [date, setDate] = useState({ date: new Date() });
  const [start, setStart] = useState(true);
  const clear = useRef(null);

  useEffect(() => {
    clear.current = setInterval(() => {
      setDate({
        date: new Date(),
      });
    }, 1000);

    return () => clearInterval(clear.current);
  }, [start]);

  return (
    <>
      <h2 className="mt-5">Date : </h2>
      <h2>{date.date.toLocaleTimeString()}</h2>
      <button
        onClick={() => setStart(!start)}
        className="btn btn-success mr-2"
      >
        Start Time
      </button>
      <button
        onClick={() => clearInterval(clear.current)}
        className="btn btn-success"
      >
        Stop Time
      </button>
    </>
  );
}

export default RefDate;
