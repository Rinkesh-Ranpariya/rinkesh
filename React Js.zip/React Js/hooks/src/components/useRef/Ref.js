import React, { useEffect, useRef } from "react";
import RefDate from "./RefDate";

function Ref() {
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current.focus();
  }, []);

  const handlerSubmit = (e) => {
    e.preventDefault();
    alert(inputRef.current.value);
  };

  return (
    <>
      <h1>useRef Hook🪝</h1>
      <hr />
      <form onSubmit={handlerSubmit}>
        <input type="text" ref={inputRef} className="mt-5" />
        <button type="submit" className="btn btn-primary ml-3">
          Submit
        </button>
      </form>
      <RefDate />
    </>
  );
}

export default Ref;
