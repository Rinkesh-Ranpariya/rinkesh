import React, { useContext } from "react";
import { nameContext, surnameContext } from "./Context";

function ChildB() {
  const name = useContext(nameContext);
  const surname = useContext(surnameContext);
  return (
    <h3 className="mt-4">
      ChildB - Hello {name} {surname}👦
    </h3>
  );
}

export default ChildB;
