import React from "react";
import ChildB from "./ChildB";

function ChildA() {
  return (
    <div className="mt-5">
      <h3>ChildA</h3>
      <ChildB/>
    </div>
  );
}

export default ChildA;
