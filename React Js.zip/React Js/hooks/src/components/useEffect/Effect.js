import axios from "axios";
import React, { useEffect, useState } from "react";

function Effect({ isDark }) {
  const [loading, setLoading] = useState(true);
  const [post, setPost] = useState([]);
  const [error, setError] = useState("");
  const [count, setCount] = useState(0);

  useEffect(() => {
    console.log("[] Run only once in it's life");
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => {
        setLoading(false);
        setPost(res.data);
        setError("");
      })
      .catch((err) => {
        setLoading(false);
        setPost([]);
        setError("Somthing Went Wrong !");
      });
  }, []);

  useEffect(() => {
    console.log("Run every time when state and props change");
    document.title = `click ${count} time...`;
  });

  return (
    <>
      <h1>useEffect Hook🪝</h1>
      <hr />
      <h3 className="mt-5">{count}</h3>
      <button onClick={() => setCount(count + 1)} className="btn btn-primary">
        Increment Count
      </button>

      <h3 className="my-5">Http - Fetch Data</h3>
      {loading ? (
        "Loading..."
      ) : (
        <table
          className="table mx-auto"
          style={{ width: "80%", color: isDark ? "white" : "black" }}
        >
          <thead className="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Title</th>
              <th scope="col">Body</th>
            </tr>
          </thead>
          <tbody>
            {post.map((ele) => (
              <tr key={ele.id}>
                <th scope="row">{ele.id}</th>
                <td>{ele.title}</td>
                <td>{ele.body}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {error ? <h3>{error}</h3> : null}
    </>
  );
}

export default Effect;
