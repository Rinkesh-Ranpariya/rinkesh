import React from 'react'

function Count({type,value}) {
    console.log(`${type}`);
  return (
    <div className='mt-4'>{type}-{value}</div>
  )
}

export default React.memo(Count)