const reels = [
  {
    channel: "World",
    avatarSrc: `https://avatars.dicebear.com/api/human/${Math.floor(Math.random()*100)}.svg`,
    song: "Tera yar hu me...",
    url: "https://images.unsplash.com/photo-1544723683-564e1e88c36a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80",
    likes: 500,
    shares: 200,
  },
  {
    channel: "Fan Page",
    avatarSrc: `https://avatars.dicebear.com/api/human/${Math.floor(Math.random()*100)}.svg`,
    song: "Dil diya galla...",
    url: "https://images.unsplash.com/photo-1613425293967-16ae72140466?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80",
    likes: 50,
    shares: 20,
  },
  {
    channel: "Rangila",
    avatarSrc: `https://avatars.dicebear.com/api/human/${Math.floor(Math.random()*100)}.svg`,
    song: "Tere sang yara...",
    url: "https://images.unsplash.com/photo-1512509312260-1e59fe1f9492?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80",
    likes: 90,
    shares: 70,
  },
  {
    channel: "Laxury",
    avatarSrc: `https://avatars.dicebear.com/api/human/${Math.floor(Math.random()*100)}.svg`,
    song: "Me nikala gadi le ke...",
    url: "https://images.unsplash.com/photo-1492112007959-c35ae067c37b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1368&q=80",
    likes: 200,
    shares: 10,
  },
];

export default reels;
