import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

function Logout() {
  let navigate = useNavigate();
  let location = useLocation();

  let data = {
    msg: "Thank-you for visiting us !",
  };

  const handleLogout = () => {
    localStorage.setItem("user", "");

    navigate("/logout", { state: data }, { replace: true });
  };

  return (
    <>
      <h1 className="mt-5">Logout</h1>
      {!localStorage.getItem("user") ? (
        <h2>You are not Logedin !</h2>
      ) : (
        <>
          {" "}
          {!location.state?.msg ? (
            <button
              onClick={handleLogout}
              className="mt-5 btn btn-outline-danger"
            >
              Logout
            </button>
          ) : (
            <h4 className="mt-5">{location.state.msg}</h4>
          )}
        </>
      )}
    </>
  );
}

export default Logout;
