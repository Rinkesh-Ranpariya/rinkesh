import { Navigate, useLocation } from "react-router-dom";

function RequirAuth({ children }) {
  const location = useLocation();
  const user = localStorage.getItem("user");

  if (user) return <>{children}</>;
  return <Navigate to="/login" state={location.pathname} replace />;
}

export default RequirAuth;
