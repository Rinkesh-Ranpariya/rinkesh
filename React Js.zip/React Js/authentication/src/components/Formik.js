import React from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
// import { object, string, email } from "yup";

function Formik() {
  const validationSchema = Yup.object({
    firstName: Yup.string().required("first name Required").max(5, "hey"),
    lastName: Yup.string().required("last name Required").max(600),
    email: Yup.string().email().max(255).required("email Required"),
  });

  const initialValues = {
    firstName: "",
    lastName: "",
    email: "",
  };

  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      alert(JSON.stringify(values));
    },
  });

  const { handleSubmit, handleChange, values, errors } = formik;
  // console.log(formik);

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="firstName">First Name</label>
      <input
        id="firstName"
        name="firstName"
        type="text"
        onChange={handleChange}
        value={values.firstName}
      />
      {errors.firstName ? (
        <div className="text-danger">{errors.firstName}</div>
      ) : null}

      <br />
      <label htmlFor="lastName">Last Name</label>
      <input
        id="lastName"
        name="lastName"
        type="text"
        onChange={handleChange}
        value={values.lastName}
      />
      {errors.lastName ? (
        <div className="text-danger">{errors.lastName}</div>
      ) : null}

      <br />
      <label htmlFor="email">Email Address</label>
      <input
        id="email"
        name="email"
        type="email"
        onChange={handleChange}
        value={values.email}
      />
      {errors.email ? <div className="text-danger">{errors.email}</div> : null}

      <button type="submit">Submit</button>
    </form>
  );
}

export default Formik;
