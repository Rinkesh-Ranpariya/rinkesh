import React, { Component } from 'react'
import "../css/navbar.css"

export class Navbar extends Component {
  render() {
    const {darkModeHandler,languageHandler,stateObj}=this.props

    let languageType=stateObj.language==="en"?"FR":"EN";
    let modeType=stateObj.darkMode?"Light Mode":"Dark Mode";

    return (
      <nav className='nav'>
          <button onClick={languageHandler}>{languageType}</button>
          <button onClick={darkModeHandler}>{modeType}</button>
      </nav>
    )
  }
}

export default Navbar