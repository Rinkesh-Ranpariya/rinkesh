// https://codesandbox.io/s/condescending-babbage-mou4y7?file=/index.js

import "./App.css";
import Main from "./components/Main";
import Navbar from "./components/Navbar";

import React, { Component } from "react";

export class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      darkMode: false,
      language: "en",
    };

    this.dataArray = [
      { en: "Hey how are you ?", fr: "sde dafe hio gry" },
      { en: "I am fine", fr: "gol uoy yyack" },
      { en: "Are you ok ?!", fr: "jol da fad gat" },
    ];
  }

  handlerDarkmode = () => {
    if (this.state.darkMode) {
      document.body.style.backgroundColor = "white";
      document.body.style.color = "black";
      // this.setState({ darkMode: false });
    } else {
      document.body.style.backgroundColor = "black";
      document.body.style.color = "white";
      // this.setState({ darkMode: true });
    }
    this.setState({ darkMode: !this.state.darkMode });
  };

  handlerLanguage = () => {
    if (this.state.language === "en") {
      this.setState({ language: "fr" });
    } else {
      this.setState({ language: "en" });
    }
  };

  render() {
    const {language } = this.state;
    return (
      <div className="App">
        <Navbar
          darkModeHandler={this.handlerDarkmode}
          languageHandler={this.handlerLanguage}
          stateObj={this.state}
        />

        {this.dataArray.map((ele, index) => {
          return (
            <Main
              key={index}
              languageName={language === "en" ? ele.en : ele.fr}
              darkMode={this.state.darkMode}
            />
          );
        })}
      </div>
    );
  }
}

export default App;