import "./App.css";
import Main from "./components/Main";
import Navbar from "./components/Navbar";
import React, { Component } from "react";
export const navbarContext = React.createContext();
export const mainContext = React.createContext();

export class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      darkMode: false,
      language: "en",
    };

    this.dataArray = [
      { en: "Hey how are you ?", fr: "sde dafe hio gry" },
      { en: "I am fine", fr: "gol uoy yyack" },
      { en: "Are you ok ?!", fr: "jol da fad gat" },
    ];
  }

  handlerDarkmode = () => {
    
    this.setState({ darkMode: !this.state.darkMode });
  };

  handlerLanguage = () => {
    if (this.state.language === "en") {
      this.setState({ language: "fr" });
    } else {
      this.setState({ language: "en" });
    }
  };

  render() {

    const { language, darkMode } = this.state;

    return (
      <div className={`App ${darkMode ? "dark" : "light"}`}>

        <navbarContext.Provider
          value={{
            darkModeHandler: this.handlerDarkmode,
            languageHandler: this.handlerLanguage,
            stateObj: this.state,
          }}
        >
          <Navbar />
        </navbarContext.Provider>

        {this.dataArray.map((ele, index) => {
          return (
            <mainContext.Provider
              value={{
                languageName: language === "en" ? ele.en : ele.fr,
                darkMode: this.state.darkMode,
              }}
            >
              <Main />
            </mainContext.Provider>
          );
        })}

      </div>
    );
  }
}

export default App;