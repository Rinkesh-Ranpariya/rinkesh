import React, { Component } from "react";
import "../css/main.css";
import { mainContext } from "../App";

export class Main extends Component {
  render() {
    return (
      <div className="parent">
        <mainContext.Consumer>
          {(ele) => {
            let style = {
              backgroundColor: ele.darkMode ? "gray" : "white",
            };
            return (
              <div className="child" style={style}>
                {ele.languageName}
              </div>
            );
          }}
        </mainContext.Consumer>
      </div>
    );
  }
}

export default Main;
