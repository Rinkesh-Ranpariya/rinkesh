import React, { Component } from "react";
import "../css/navbar.css";
import { navbarContext } from "../App";

export class Navbar extends Component {
  render() {
    return (
      <nav className="nav">
        <navbarContext.Consumer>
          {(ele) => {
            let languageType = ele.stateObj.language === "en" ? "FR" : "EN";
            let modeType = ele.stateObj.darkMode ? "Light Mode" : "Dark Mode";

            return (
              <>
                <button onClick={ele.languageHandler}>{languageType}</button>
                <button onClick={ele.darkModeHandler}>{modeType}</button>
              </>
            );
          }}
        </navbarContext.Consumer>
      </nav>
    );
  }
}

export default Navbar;
