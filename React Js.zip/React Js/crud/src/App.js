import "./App.css";
import { useEffect, useState } from "react";
import TableHead from "./components/TableHead";
import Modal from "./components/Modal";

function App() {
  const [data, setData] = useState([]);
  const [error, setError] = useState("");
  const [addNewData, setAddNewData] = useState(false);
  const [modalData, setModalData] = useState({
    index: "",
    id: "",
    image: "",
    title: "",
    price: "",
    category: "",
    description: "",
    rating: { rate: "", count: "" },
  });

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((data) => setData(data))
      .catch(() => setError("Somthing Went Wronge !!"));
  }, []);

  const handleDelete = (index) => {
    data.splice(index, 1);
    setData([...data]);
  };

  const handleView = (index) => {
    setModalData({
      index: index,
      id: data[index].id,
      image: data[index].image,
      title: data[index].title,
      price: data[index].price,
      category: data[index].category,
      description: data[index].description,
      rating: {
        rate: data[index].rating.rate,
        count: data[index].rating.count,
      },
    });
  };

  const handlerChange = (e) => {
    if (e.target.name === "rate" || e.target.name === "count") {
      setModalData({
        ...modalData,
        rating: { ...modalData.rating, [e.target.name]: e.target.value },
      });
    } else {
      setModalData({ ...modalData, [e.target.name]: e.target.value });
    }
  };

  const handlerSubmit = (index) => {
    if (addNewData) {
      setData([...data, modalData]);
      setAddNewData(false);
    } else {
      data.splice(index, 1, modalData);
      setData([...data]);
    }
  };

  const handleAddNewData = (e) => {
    setModalData({
      index: "",
      id: "",
      image: "",
      title: "",
      price: "",
      category: "",
      description: "",
      rating: { rate: "", count: "" },
    });
  };

  return (
    <>
      <input
        type="button"
        value="Add Data"
        className="btn btn-primary d-block mx-auto m-3"
        data-toggle="modal"
        data-target="#exampleModal"
        onClick={() => {
          handleAddNewData();
          setAddNewData(true);
        }}
      />

      <div className="App">
        <table id="table" className="table">
          <TableHead />
          <tbody id="tableBody">
            {data.length > 0
              ? data.map((ele, index) => (
                  <tr className="trData" key={ele.id}>
                    <td>{ele.id}</td>
                    <td>
                      <img
                        src={ele.image}
                        alt="img"
                        width="50px"
                        height="50px"
                      />
                    </td>
                    <td className="title">{ele.title}</td>
                    <td>{ele.price}</td>
                    <td>{ele.category}</td>
                    <td>{ele.description}</td>
                    <td>
                      count:{ele.rating.count} rate:{ele.rating.rate}
                    </td>
                    <td>
                      <button
                        className="btn btn-danger"
                        onClick={() => handleDelete(index)}
                      >
                        Delete
                      </button>
                      <button
                        data-toggle="modal"
                        data-target="#exampleModal"
                        className="btn btn-success mt-1"
                        onClick={() => handleView(index)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))
              : null}
          </tbody>
        </table>
        {error ? <h3>{error}</h3> : null}

        <Modal data={data} handlerChange={handlerChange} handlerSubmit={handlerSubmit} modalData={modalData} addNewData={addNewData}/>
      </div>
    </>
  );
}

export default App;
