import React from "react";

function Modal({ data,handlerChange, handlerSubmit, modalData, addNewData }) {

  const {title,image,id,price,category,description,rating}=modalData
  return (
    <>
      <div className="modal fade" id="exampleModal" tabIndex="-1">
        <div className="modal-dialog modal-dialog-centered">
          
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="modal-title">
                  {title}
                </h5>
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>

              <div className="modal-body" id="modal-body">
              
                <p>
                  <img
                    src={
                      image
                        ? image
                        : "https://thecartridgeshoponline.co.uk/wp-content/uploads/2021/03/default-product-image.png"
                    }
                    alt="img"
                    width="150px"
                    height="150px"
                  />
                </p>
                <p>
                  Id :{" "}
                  <input
                    type="text"
                    name="id"
                    id=""
                    value={id}
                    onChange={handlerChange}
                  />
                </p>

                <p>
                  Image :{" "}
                  <input
                    type="text"
                    name="image"
                    id=""
                    value={image}
                    onChange={handlerChange}
                  />
                </p>
                <p>
                  Title :{" "}
                  <input
                    type="text"
                    name="title"
                    id=""
                    value={title}
                    onChange={handlerChange}
                  />
                </p>
                <p>
                  Price :{" "}
                  <input
                    type="text"
                    name="price"
                    id=""
                    value={price}
                    onChange={handlerChange}
                  />
                </p>
                <p>
                  Category :{" "}
                  <input
                    type="text"
                    name="category"
                    id=""
                    value={category}
                    onChange={handlerChange}
                  />
                </p>
                <p>
                  Description :{" "}
                  <input
                    type="text"
                    name="description"
                    id=""
                    value={description}
                    onChange={handlerChange}
                  />
                </p>
                <p>
                  Count :{" "}
                  <input
                    type="text"
                    name="count"
                    id=""
                    value={rating.count}
                    onChange={handlerChange}
                  />
                </p>
                <p>
                  Rate :{" "}
                  <input
                    type="text"
                    name="rate"
                    id=""
                    value={rating.rate}
                    onChange={handlerChange}
                  />
                </p>
                
              </div>

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-dismiss="modal"
                >
                  Close
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  data-dismiss="modal"
                  disabled={!title||!image||!id||!price||!category||!description||!rating.count||!rating.rate}
                  onClick={() => handlerSubmit(modalData.index)}
                >
                  {addNewData ? "Add Data" : "Save changes"}
                </button>
              </div>
            </div>
        </div>
      </div>
    </>
  );
}

export default Modal;
