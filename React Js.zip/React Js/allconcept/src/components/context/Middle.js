import React, { Component } from 'react'
import Consumercomp from './Consumercomp'

class Middle extends Component {
  render() {
    return (
      <>
          <Consumercomp/>
      </>
    )
  }
}

export default Middle