import React from "react";
import { Link } from "react-router-dom";
import PropTypes from 'prop-types';

// function Navbar({logo,title}) {
function Navbar(props) {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <Link className="navbar-brand" to="/">
          {/* {logo} */}
          {props.logo}
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">
                Home <span className="sr-only">(current)</span>
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/nameform">
                Nameform
              </Link>
            </li>

            <li className="nav-item dropdown">
              <Link
                className="nav-link dropdown-toggle"
                to=""
                id="navbarDropdown"
                role="button"
                data-toggle="dropdown"
                aria-expanded="false"
              >
                Clock
              </Link>
              <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                <Link className="dropdown-item" to="/clock">
                  ClassClock
                </Link>
                <Link className="dropdown-item" to="/fclock">
                  FunctionClock
                </Link>
              </div>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/context">
                Context
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/withcounter">
                Hoc
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/renderprops">
                Render-Props
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/errorboundary">
                ErrorBoundary
              </Link>
            </li>

            <li className="nav-item dropdown">
              <Link
                className="nav-link dropdown-toggle"
                to=""
                id="navbarDropdown"
                role="button"
                data-toggle="dropdown"
                aria-expanded="false"
              >
                Lifecycle Methods
              </Link>
              <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                <Link className="dropdown-item" to="/mounting">
                  Mounting
                </Link>
                <Link className="dropdown-item" to="/updating">
                  Updating
                </Link>
                <Link className="dropdown-item" to="/unmounting">
                  Unmounting
                </Link>
                <Link className="dropdown-item" to="/error">
                  Error Handling
                </Link>
              </div>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/login">
                Login
              </Link>
            </li>
          </ul>
          <button type="button" className="btn btn-light" onClick={props.func}>
            {props.mode.txt}
          </button>
        </div>
      </nav>
    </div>
  );
}

Navbar.propTypes = {
  logo: PropTypes.string,
  title: PropTypes.string,
  mode: PropTypes.bool,
  func: PropTypes.func.isRequired,
};

Navbar.defaultProps = {
  logo:"Navbar",
  title:"Home",
  mode:true,
  func:"function"
};


export default Navbar;
