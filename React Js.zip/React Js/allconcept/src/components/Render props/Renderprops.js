import React, { Component } from "react";
import Click from "./Click";
import Commoncode from "./Commoncode";
import Mouseover from "./Mouseover";

export class Renderprops extends Component {
  render() {
    return (
      <div>
        <h1 className="mb-5">Render Props</h1>
        <Commoncode
          render={(count, handler) => <Click count={count} handler={handler} />}
        />
        <Commoncode
          render={(count, handler) => (
            <Mouseover count={count} handler={handler} />
          )}
        />

        {/* As a children */}
        {/* <Commoncode>
          {(count, handler) => <Click count={count} handler={handler} />}
        </Commoncode>
        <Commoncode>
          {(count, handler) => <Mouseover count={count} handler={handler} />}
        </Commoncode> */}
      </div>
    );
  }
}

export default Renderprops;
