import React, { Component } from "react";

export class Mountingc1 extends Component {
  constructor(props) {
    super(props);
    this.state = { name: "Rinkesh" };
    console.log("child constructor");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("child getDerivedStateFromProps");
    return null;
  }

  componentDidMount() {
    console.log("child componentDidMount");
  }

  render() {
    console.log("child render");

    return <h5>Child Mounting</h5>;
  }
}

export default Mountingc1;
