import React, { Component } from "react";

export class Updatingc1 extends Component {
  constructor(props) {
    super(props);
    this.state = { name: "Rinkesh" };
    console.log("child constructor");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("child getDerivedStateFromProps");
    return null;
  }

  componentDidMount() {
    console.log("child componentDidMount");
  }

  shouldComponentUpdate() {
    console.log("child shouldComponentUpdate");
    return true;
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log("child getSnapshotBeforeUpdate");
    return null;
  }

  componentDidUpdate() {
    console.log("child componentDidUpdate");
  }

  render() {
    console.log("child render");
    return (
      <>
        <h5>child Updating</h5>
      </>
    );
  }
}

export default Updatingc1;
