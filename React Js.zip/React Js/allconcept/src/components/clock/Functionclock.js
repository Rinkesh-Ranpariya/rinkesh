import React, { useEffect, useState } from "react";

function Functionclock() {

  const [state, setstate] = useState({ date: new Date() });

  function tick() {
    setstate({
      date: new Date(),
    });
  }

  useEffect(() => {
    let timerID = setInterval(tick, 1000);

    return () => {
      clearInterval(timerID);
    };
  }, []);

  return (
    <div>
      <h1>Function Component ⏰</h1>
      <h2>It is {state.date.toLocaleTimeString()} ...</h2>
    </div>
  );
}

export default Functionclock;
