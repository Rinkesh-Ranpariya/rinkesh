import React, { Component } from "react";
import Click from "./Click";
import Hover from "./Hover";

export class withCounter extends Component {
  render() {
    return (
      <>
        <h1 className="mb-5">HOC</h1>
        <Click name={"Click"} />
        <Hover name="MouseOver" />
      </>
    );
  }
}

export default withCounter;
