import React, { Component } from "react";
import axios from "axios";

export class Httpsclass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      post: [],
      error: "",
    };
  }

  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => this.setState({ post: res.data }))
      .catch((err) => this.setState({ error: "Somthing went wronge !!!" }));
  }

  render() {
    const { post, error } = this.state;
    console.log(post);
    return (
      <>
        {post &&
          post.map((ele) => {
            // let data = <li key={ele.id}>{ele.title}</li>;

            <div className="card" style="width: 18rem;">
              <img src="..." className="card-img-top" alt="..." />
              <div className="card-body">
                <h5 className="card-title">Card title</h5>
                <p className="card-text">
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </p>
                <a href="#" className="btn btn-primary">
                  Go somewhere
                </a>
              </div>
            </div>;
          })}

        {error && error}
      </>
    );
  }
}

export default Httpsclass;
