import React, { useState } from "react";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Form from "./components/Form";
import Clock from "./components/clock/Clock";
import Functionclock from "./components/clock/Functionclock";
import Provider from "./components/context/Provider";
import WithCounter from "./components/Hoc/WithCounter";
import Renderprops from "./components/Render props/Renderprops";
import Parent from "./components/Errorboundary/Parent";
import Mounting from "./components/lifecycle/Mounting";
import LoginControl from "./components/LoginControl";
import Portal from "./components/portal/Portal";
import Updating from "./components/lifecycle/Updating";
// import Httpsclass from "./components/HTTP/Httpsclass";

function App() {
  const [mode, setMode] = useState({
    isDark: false,
    txt: "Dark Mode",
    styleObj: {
      color: "black",
      backgroundColor: "white",
    },
  });

  const handlerMode = () => {
    if (mode.isDark === false) {
      setMode({
        isDark: true,
        txt: "Light Mode",
        styleObj: {
          color: "white",
          backgroundColor: "black",
        },
      });
    } else {
      setMode({
        isDark: false,
        txt: "Dark Mode",
        styleObj: {
          color: "black",
          backgroundColor: "white",
        },
      });
    }
  };

  return (
    <Router>
      <div className="App" style={mode.styleObj}>
        <Navbar logo="Coin" title="Home" mode={mode} func={handlerMode} />

        <div className="container mt-5">
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route exact path="/nameform" element={<Form />} />

            <Route exact path="/clock" element={<Clock />} />
            <Route exact path="/fclock" element={<Functionclock />} />

            <Route exact path="/context" element={<Provider />} />
            <Route exact path="/withcounter" element={<WithCounter />} />
            <Route exact path="/renderprops" element={<Renderprops />} />
            <Route exact path="/errorboundary" element={<Parent />} />

            <Route exact path="/mounting" element={<Mounting />} />
            <Route exact path="/updating" element={<Updating />} />
            <Route exact path="/unmounting" element={<Functionclock />} />
            <Route exact path="/error" element={<Functionclock />} />

            <Route exact path="/login" element={<LoginControl />} />
          </Routes>
        </div>

        {/* <Httpsclass /> */}
        <Portal />
        
      </div>
    </Router>
  );
}

export default App;
